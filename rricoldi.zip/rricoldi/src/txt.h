#ifndef __TXT_H
#define __TXT_H

/*
    Aqui Temos uma funcao para iniciar o arquivo .txt
*/

void iniciaTxt(char txt[]);


#endif